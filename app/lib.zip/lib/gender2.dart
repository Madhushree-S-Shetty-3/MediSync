import 'package:flutter/material.dart';
import 'package:app/home.dart';

class Gender2 extends StatefulWidget {
  const Gender2({Key? key}) : super(key: key);

  @override
  _Gender2State createState() => _Gender2State();
}

class _Gender2State extends State<Gender2> {
  String? selectedGender;

  void navigateToNextPage() {
    if (selectedGender != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => selectedGender == 'Female' ? Home() : Home(),
        ),
      );
    }
  }

  void selectGender(String gender) {
    setState(() {
      selectedGender = gender;
    });
  }

  Widget buildGenderButton(String gender, String imagePath) {
    bool isSelected = selectedGender == gender;

    return GestureDetector(
      onTap: () => selectGender(gender),
      child: Stack(
        children: [
          Container(
            width: 182,
            height: 192,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF2C2C2C), Color(0xFF3E3E3E)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(25),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.3),
                  spreadRadius: 3,
                  blurRadius: 15,
                  offset: const Offset(5, 7),
                ),
              ],
              border: Border.all(
                color: isSelected ? Color(0xFF8766EB) : Colors.transparent,
                width: 4,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 30, top: 5),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  imagePath,
                  width: 120,
                  height: 140,
                ),
                const SizedBox(height: 10),
                Text(
                  gender,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w400,
                    fontFamily: 'Inter',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF13171D),
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 50, left: 10, right: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "Select a Gender",
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Inter',
                ),
              ),
              const SizedBox(height: 50),
              Center(
                child: buildGenderButton('Female', 'assets/g1.png'),
              ),
              const SizedBox(height: 80),
              Center(
                child: buildGenderButton('Male', 'assets/b1.png'),
              ),
              const SizedBox(height: 80),
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const Home()),
                      );
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: Text(
                        "Skip",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.w200,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 240),
                  GestureDetector(
                    onTap: navigateToNextPage,
                    child: Container(
                      width: 35,
                      height: 35,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 46, 46, 46),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Icon(
                        Icons.arrow_forward,
                        color: Color.fromARGB(255, 220, 220, 220),
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
