import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:app/prescription_page.dart';

class FamilyHistory extends StatelessWidget {
  const FamilyHistory({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF13171E),
      appBar: AppBar(
        backgroundColor: Colors.black,
        actions: [
          Icon(
            Icons.arrow_back_ios_new_outlined,
            size: 20,
            color: const Color.fromARGB(0, 158, 158, 158),
          )
        ],
        title: Text(
          "Family History",
          style: TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PrescriptionPage()),
          );
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.grey,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
    );
  }
}
