import 'package:app/prescription.dart';
import 'package:flutter/material.dart';

class Up2 extends StatelessWidget {
  const Up2({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF13171D),
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(51, 54, 58, 1),
        title: TextField(
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.search, color: Colors.white),
            hintText: 'Search..',
            hintStyle: TextStyle(color: Colors.white),
            border: InputBorder.none,
          ),
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: IconButton(
                icon: Icon(Icons.account_circle, color: Colors.white, size: 30.0,),
                onPressed: () {},
              ),
            ),
          ),
        ],
      ),
       
      bottomNavigationBar: SizedBox(height: 0), // Remove the default bottom navigation bar
      bottomSheet: Container( // Add your rectangle background at the bottom
        height: 150,
        width: 400,
        decoration: BoxDecoration(
          color: Color.fromRGBO(51, 54, 58, 1), // Set the background color of the rectangle
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)), // Optional: Add rounded corners to the top edge
        ),
        child: Padding(
          padding: const EdgeInsets.only( left: 40.0,top: 20,right: 40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                "Upload Prescription / Medical Documents :",
                style: TextStyle(color: Color.fromRGBO(208, 200, 236, 1), fontSize: 14,fontFamily:'inter'),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color:Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(color: Color.fromRGBO(172, 145, 190, 1), width: 1),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.camera, color: Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Prescription()));},
                        ),
                      ),
                      SizedBox(height: 8), // Add some space between the icon and text
                      Text("Camera", style: TextStyle(color: Colors.white,fontSize:10,fontWeight:FontWeight.w100),),
                    ],
                  ),
                  SizedBox(width: 16), // Add some space between the camera and gallery icons
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(color: Color.fromRGBO(172, 145, 190, 1), width: 1),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.photo_library, color: Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Prescription()));},
                        ),
                      ),
                      SizedBox(height: 8), // Add some space between the icon and text
                      Text("Gallery", style: TextStyle(color: Colors.white,fontSize:10,fontWeight:FontWeight.w100)),
                    ],
                  ),
                  SizedBox(width: 16), // Add some space between the camera and gallery icons
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(color: Color.fromRGBO(172, 145, 190, 1), width: 1),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.document_scanner, color:  Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Prescription()));},
                        ),
                      ),
                      SizedBox(height: 8), // Add some space between the icon and text
                      Text("Document", style: TextStyle(color: Colors.white,fontSize:10,fontWeight:FontWeight.w100)),
                    ],
                  ),
                  SizedBox(width: 16), // Add some space between the camera and gallery icons
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(color: Color.fromRGBO(172, 145, 190, 1), width: 1),
                        ),
                        child: IconButton(
                          icon: Icon(Icons.create_new_folder_rounded, color:  Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Prescription()));},
                        ),
                      ),
                      SizedBox(height: 8), // Add some space between the icon and text
                      Text("New Folder", style: TextStyle(color: Colors.white,fontSize:10,fontWeight:FontWeight.w100)),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: Up2(),
  ));
}