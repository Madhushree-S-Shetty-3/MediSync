import 'package:flutter/material.dart';

class PrescriptionPage extends StatelessWidget {
  const PrescriptionPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF13171D),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(51, 54, 58, 1),
        title: const TextField(
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.search, color: Colors.white),
            hintText: 'Search..',
            hintStyle: TextStyle(color: Colors.white),
            border: InputBorder.none,
          ),
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: IconButton(
                icon: const Icon(
                  Icons.account_circle,
                  color: Colors.white,
                  size: 30.0,
                ),
                onPressed: () {},
              ),
            ),
          ),
        ],
      ),

      bottomNavigationBar:
          const SizedBox(height: 0), // Remove the default bottom navigation bar
      bottomSheet: Container(
        // Add your rectangle background at the bottom
        height: 150,
        width: 400,
        decoration: const BoxDecoration(
          color: Color.fromRGBO(
              51, 54, 58, 1), // Set the background color of the rectangle
          borderRadius: BorderRadius.vertical(
              top: Radius.circular(
                  20)), // Optional: Add rounded corners to the top edge
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: 20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const Text(
                "Upload Prescription / Medical Documents :",
                style: TextStyle(
                    color: Color.fromRGBO(208, 200, 236, 1),
                    fontSize: 14,
                    fontFamily: 'inter'),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(
                              color: const Color.fromRGBO(172, 145, 190, 1),
                              width: 1),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.camera,
                              color: Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {},
                        ),
                      ),
                      const SizedBox(
                          height:
                              8), // Add some space between the icon and text
                      const Text(
                        "Camera",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w100),
                      ),
                    ],
                  ),
                  const SizedBox(
                      width:
                          16), // Add some space between the camera and gallery icons
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(
                              color: const Color.fromRGBO(172, 145, 190, 1),
                              width: 1),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.photo_library,
                              color: Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {},
                        ),
                      ),
                      const SizedBox(
                          height:
                              8), // Add some space between the icon and text
                      const Text("Gallery",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w100)),
                    ],
                  ),
                  const SizedBox(
                      width:
                          16), // Add some space between the camera and gallery icons
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(
                              color: const Color.fromRGBO(172, 145, 190, 1),
                              width: 1),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.document_scanner,
                              color: Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {},
                        ),
                      ),
                      const SizedBox(
                          height:
                              8), // Add some space between the icon and text
                      const Text("Document",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w100)),
                    ],
                  ),
                  const SizedBox(
                      width:
                          16), // Add some space between the camera and gallery icons
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color.fromRGBO(51, 54, 58, 1),
                          border: Border.all(
                              color: const Color.fromRGBO(172, 145, 190, 1),
                              width: 1),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.create_new_folder_rounded,
                              color: Color.fromRGBO(247, 247, 248, 1)),
                          iconSize: 25,
                          onPressed: () {},
                        ),
                      ),
                      const SizedBox(
                          height:
                              8), // Add some space between the icon and text
                      const Text("New Folder",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w100)),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
