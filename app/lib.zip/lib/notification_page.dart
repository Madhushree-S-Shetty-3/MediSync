import 'package:app/home.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:app/cyclecontd.dart';

class NotificationPage extends StatefulWidget {
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();
  TextEditingController _descriptionController = TextEditingController();
  TextEditingController _timeController = TextEditingController();
  List<String> _notifications = [];

  void _openCycleSettings() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => CycleSettingsPage()),
    );
  }

  void _addReminder(DateTime selectedDate) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xFF13171D),
          title: const Text(
            'Add Reminder',
            style: TextStyle(color: Colors.white),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Date: ${selectedDate.toLocal()}'.split(' ')[0]),
              TextField(
                controller: _timeController,
                style: TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Time (e.g., 10:45 AM)',
                  labelStyle:
                      TextStyle(color: Color.fromARGB(255, 158, 157, 157)),
                ),
              ),
              TextField(
                controller: _descriptionController,
                style: TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Description',
                  labelStyle:
                      TextStyle(color: Color.fromARGB(255, 158, 157, 157)),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _notifications.add(
                      '${selectedDate.toLocal().toString().split(' ')[0]} at ${_timeController.text}: ${_descriptionController.text}');
                  _descriptionController.clear();
                  _timeController.clear();
                });
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF2C2D30),
                foregroundColor: Color(0xFFC1C1C1),
              ),
              child: Text('Add'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    var container3 = Container(
      margin: const EdgeInsets.only(left: 15, right: 15, top: 0),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Theme(
        data: ThemeData(
          primaryColor: Colors.grey,
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: 0),
          child: TableCalendar(
            focusedDay: _focusedDay,
            firstDay: DateTime(2020),
            lastDay: DateTime(2030),
            calendarFormat: CalendarFormat.month,
            selectedDayPredicate: (day) {
              return isSameDay(_selectedDay, day);
            },
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
              _addReminder(selectedDay);
            },
            onPageChanged: (focusedDay) {
              _focusedDay = focusedDay;
            },
            availableCalendarFormats: const {
              CalendarFormat.month: 'Month',
            },
            headerStyle: const HeaderStyle(
              titleTextStyle: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            daysOfWeekStyle: const DaysOfWeekStyle(
              weekdayStyle: TextStyle(
                color: Color(0xFF8766EB),
              ),
              weekendStyle: TextStyle(
                color: Color.fromARGB(255, 158, 130, 242),
              ),
            ),
            calendarStyle: CalendarStyle(
              defaultTextStyle: TextStyle(
                color: Colors.grey[600],
              ),
            ),
            daysOfWeekHeight: 30.0,
          ),
        ),
      ),
    );

    var center = Center(
      child: container3,
    );

    return Scaffold(
      backgroundColor: Color(0xFF13171D),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon:
              Icon(Icons.arrow_back, color: Color.fromARGB(255, 218, 218, 218)),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => Home(),
              ),
            );
          },
        ),
        title: Text(''),
      ),
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Column(
          children: [
            center,
            Container(
              margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Center(
                        child: Container(
                          width: 320,
                          height: 50,
                          decoration: BoxDecoration(
                              color: Color(0xFF2C2D30),
                              borderRadius: BorderRadius.circular(15)),
                          child: Center(
                            child: Row(
                              children: [
                                ElevatedButton(
                                  iconAlignment: IconAlignment.end,
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Color(0xFF2C2D30),
                                      foregroundColor: Color(0xFFC1C1C1),
                                      alignment: Alignment.center),
                                  onPressed: () {},
                                  child: const Center(
                                    child: Text(
                                      'Menstrual Reminder',
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Container(
                    width: 320,
                    height: 50,
                    decoration: BoxDecoration(
                        color: Color(0xFF2C2D30),
                        borderRadius: BorderRadius.circular(15)),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF2C2D30),
                        foregroundColor: Color(0xFFC1C1C1),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Cyclecontd(),
                          ),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Cycle Settings',
                            textAlign: TextAlign.left,
                          ),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: Colors.grey,
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 320,
              height: 170,
              margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
              decoration: BoxDecoration(
                color: Color(0xFF2C2D30),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: const EdgeInsets.all(15),
                    child: Text(
                      'Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  ListView.builder(
                    shrinkWrap: true,
                    itemCount: _notifications.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(
                          _notifications[index],
                          style: TextStyle(color: Colors.grey, fontSize: 15),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CycleSettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cycle Settings'),
      ),
      body: Center(
        child: Text('Cycle Settings Page'),
      ),
    );
  }
}
