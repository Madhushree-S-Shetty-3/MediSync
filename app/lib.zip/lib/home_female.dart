import 'package:flutter/cupertino.dart';

class HomeFemale extends StatelessWidget {
  const HomeFemale({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
