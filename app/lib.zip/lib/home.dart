import 'package:app/prescription_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'notification_page.dart';
import 'profile_page.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  void _navigateToPage(BuildContext context, Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFF13171D),
        resizeToAvoidBottomInset: true,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(top: 45, left: 10, right: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Hi,Jaydev",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 28,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          "19 years, Male",
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w100),
                        ),
                      ],
                    ),
                    ElevatedButton(
                      onPressed: () {
                        _navigateToPage(context, NotificationPage());
                      },
                      style: ElevatedButton.styleFrom(
                        shape: const CircleBorder(),
                        padding: EdgeInsets.all(15),
                        backgroundColor: Colors.transparent,
                        elevation: 0,
                      ),
                      child: const Icon(
                        Icons.notifications,
                        size: 30,
                        color: Colors.white,
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Center(
                  child: Container(
                    width: 320,
                    height: 139,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: const Color.fromARGB(255, 51, 52, 53),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.3),
                          spreadRadius: 4,
                          blurRadius: 9,
                          offset: const Offset(4, 4),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(top: 10, left: 25),
                      child: Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Bio-Mass Index",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500,
                                  )),
                              const SizedBox(
                                height: 6,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Container(
                                  width: 75,
                                  height: 35,
                                  decoration: BoxDecoration(
                                    color:
                                        const Color.fromARGB(210, 70, 71, 72),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: const Center(
                                    child: Text(
                                      "64 kg",
                                      style: TextStyle(
                                          color: Color(0xFF62AA69),
                                          fontSize: 15,
                                          fontFamily: 'Inter'),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 60),
                                child: Container(
                                  width: 75,
                                  height: 35,
                                  decoration: BoxDecoration(
                                    color:
                                        const Color.fromARGB(210, 70, 71, 72),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: const Center(
                                    child: Text(
                                      "123 cm",
                                      style: TextStyle(
                                          color: Color.fromARGB(
                                              255, 159, 158, 158),
                                          fontSize: 15,
                                          fontFamily: 'Inter'),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          Stack(
                            children: [
                              Image.asset(
                                'assets/bmi.png',
                                width: 120,
                                height: 140,
                              ),
                              const Padding(
                                padding:
                                    const EdgeInsets.only(top: 70, left: 35),
                                child: const Text("21.7",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 24,
                                      fontWeight: FontWeight.w500,
                                    )),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  height: 65,
                  width: 320,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: const Color.fromARGB(255, 51, 52, 53),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(.3),
                        spreadRadius: 4,
                        blurRadius: 9,
                        offset: const Offset(4, 4),
                      ),
                    ],
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(top: 5, left: 25),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Tags",
                          style: TextStyle(
                              color: Color.fromARGB(255, 187, 186, 186),
                              fontSize: 16,
                              fontWeight: FontWeight.w300),
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 30),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Before Meal Sugar",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w300),
                              ),
                              Text(
                                "After Meal Sugar",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w300),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Center(
                  child: Container(
                    width: 320,
                    height: 296,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: const Color.fromARGB(255, 51, 52, 53),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.3),
                          spreadRadius: 4,
                          blurRadius: 9,
                          offset: const Offset(4, 4),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 25, top: 10),
                      child: Column(
                        children: [
                          const Row(
                            children: [
                              Text(
                                "Blood Sugar",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w300),
                              ),
                              SizedBox(
                                width: 50,
                              ),
                              Text(
                                "Avg this week",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w200),
                              ),
                              SizedBox(
                                width: 7,
                              ),
                              Text(
                                "128 mg/dL",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 4,
                          ),
                          Row(
                            children: [
                              ClipOval(
                                child: Container(
                                  color: const Color(0xFF9CDDC2),
                                  height: 6,
                                  width: 6,
                                ),
                              ),
                              const SizedBox(
                                width: 5,
                              ),
                              const Text(
                                "Before Meal",
                                style: TextStyle(
                                  color: Color.fromARGB(255, 201, 200, 200),
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              ClipOval(
                                child: Container(
                                  color: const Color(0xFF91C8DF),
                                  height: 6,
                                  width: 6,
                                ),
                              ),
                              const SizedBox(
                                width: 5,
                              ),
                              const Text(
                                "After Meal",
                                style: TextStyle(
                                  color: Color.fromARGB(255, 201, 200, 200),
                                ),
                              ),
                            ],
                          ),
                          Image.asset(
                            'assets/graph.png',
                            width: 320,
                            height: 220,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                    width: 250,
                    height: 55,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      color: const Color.fromARGB(255, 51, 52, 53),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.3),
                          spreadRadius: 4,
                          blurRadius: 9,
                          offset: const Offset(4, 4),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          ElevatedButton(
                            onPressed: () {
                              _navigateToPage(context, const ProfilePage());
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              elevation: 0,
                              shadowColor: Colors.transparent,
                              shape: CircleBorder(),
                              padding: EdgeInsets.all(0),
                            ),
                            child: Icon(
                              Icons.account_circle_rounded,
                              size: 38,
                              color: Colors.white,
                            ),
                          ),
                          Center(
                            child: ElevatedButton(
                              onPressed: () {
                                _navigateToPage(
                                    context, const PrescriptionPage());
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    Color.fromARGB(255, 152, 123, 239),
                                elevation: 0,
                                shadowColor: Color.fromARGB(226, 27, 27, 27),
                                shape: CircleBorder(),
                                padding: EdgeInsets.all(0),
                              ),
                              child: Icon(
                                Icons.add,
                                size: 38,
                                color: Color.fromARGB(255, 255, 255, 255),
                              ),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              _navigateToPage(context, NotificationPage());
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              elevation: 0,
                              shadowColor: Colors.transparent,
                              shape: CircleBorder(),
                              padding: EdgeInsets.all(0),
                            ),
                            child: Icon(
                              Icons.calendar_month_rounded,
                              size: 38,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ))
              ],
            ),
          ),
        ));
  }
}
