import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Cyclecontd extends StatefulWidget {
  const Cyclecontd({Key? key}) : super(key: key);

  @override
  _CyclecontdState createState() => _CyclecontdState();
}

class _CyclecontdState extends State<Cyclecontd> {
  String _selectedDate = "Select Date";

  void _showPicker(BuildContext context, List<String> options) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext builder) {
        return Container(
          height: MediaQuery.of(context).copyWith().size.height / 3,
          color: const Color(0xFF414141),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text(
                      'Cancel',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text(
                      'Done',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: CupertinoTheme(
                  data: CupertinoThemeData(
                    textTheme: CupertinoTextThemeData(
                      dateTimePickerTextStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  child: CupertinoPicker(
                    backgroundColor: const Color(0xFF414141),
                    itemExtent: 32,
                    onSelectedItemChanged: (int value) {},
                    children: options.map((String value) {
                      return Text(value,
                          style: const TextStyle(color: Colors.white));
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showDatePicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext builder) {
        return Container(
          height: MediaQuery.of(context).copyWith().size.height / 3,
          color: const Color(0xFF414141),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text(
                      'Cancel',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text(
                      'Done',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: CupertinoDatePicker(
                  backgroundColor: const Color(0xFF414141),
                  mode: CupertinoDatePickerMode.date,
                  initialDateTime: DateTime.now(),
                  onDateTimeChanged: (DateTime newDateTime) {
                    setState(() {
                      _selectedDate =
                          "${newDateTime.month}/${newDateTime.day}/${newDateTime.year}";
                    });
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF13171E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF000000),
        leading: IconButton(
          icon: const Icon(Icons.chevron_left, color: Color(0xFF9F9F9F)),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: const Text(
          "Cycle Settings",
          style: TextStyle(
            color: Colors.white,
            fontSize: 19,
            fontWeight: FontWeight.bold,
            fontFamily: "Inter",
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 20, left: 16, right: 16),
        child: Column(
          children: [
            _buildOptionItem(
              title: "Menstrual days",
              subtitle: "How many days does your period usually last?",
              onTap: () => _showPicker(
                  context,
                  List.generate(
                      8, (index) => (4 + index).toString())), // Range 4-11
            ),
            const SizedBox(height: 16),
            _buildOptionItem(
              title: "Cycle days",
              subtitle: "How many days is the interval between your periods?",
              onTap: () => _showPicker(
                  context,
                  List.generate(
                      16, (index) => (15 + index).toString())), // Range 15-30
            ),
            const SizedBox(height: 16),
            _buildOptionItem(
              title: "Last menstrual start date",
              subtitle: _selectedDate,
              onTap: () => _showDatePicker(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionItem(
      {required String title,
      required String subtitle,
      required VoidCallback onTap}) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF414141),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: ListTile(
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.normal,
            fontFamily: "Inter",
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(
            color: Color(0xFF9F9F9F),
            fontSize: 12,
            fontWeight: FontWeight.w100,
            fontFamily: "Inter",
          ),
        ),
        trailing: const Icon(Icons.chevron_right, color: Color(0xFF9F9F9F)),
        onTap: onTap,
      ),
    );
  }
}

void main() {
  runApp(const MaterialApp(
    home: Cyclecontd(),
  ));
}
